
const container = document.getElementById('container')
var welcome = document.createElement('h1')
welcome.innerHTML = 'Welcome to GardenX!'